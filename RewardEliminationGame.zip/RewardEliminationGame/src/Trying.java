/*
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;

public class Trying {
    LinkedList<String> list = new LinkedList<>();


    public static void main(String[] args) throws Exception


                /*else {//Game has 2 or more players
          GameIterator iterator=new GameIterator(size);
          while(iterator.hasNext()){
              if(iterator.next()==node){//the player is in the game
                    RENode current=node.next;//3
                    RENode temp=node.previous;//previous node of the node to be removed
                    //losing all references to node to be removed
                    temp.next=node.next;//the temps next is no longer the node but the curr node's next(losing ref to curr
                    (current).previous=node.previous;
                    size--;
            }
             else{//the player is not in the game
                System.out.println("There is no such player in this game");
            }
        }
    }*/


        //System.out.println(list.size());
        /*Iterator<String>iterator= list.iterator();
        String [] index=new String[list.size()];
         int i = 0;

            while (iterator.hasNext()&& i< list.size()) {
                index[i] = iterator.next();
                i++;
               if (index[i].equalsIgnoreCase(element)){
                   System.out.println(element+" is at index "+i);
                }

               else if(!iterator.hasNext())
                   throw new Exception("element "+element+" is not in list");


            }*/


        /*public void removePlayers(RENode node){
            if(head==null)//list is empty{
              System.out.println("There are no players to remove");
              }
              else if(size>=1){
                GameIterator iterator=new GameIterator();
                while(iterator.hasNext){
                  if(iterator.next==node){
                    if(size==1){
                      head=null;
                      size=0;
                    }
                     else{
                     RENode current=node;
                     temp=current.previous;//previous node of the node to be removed
                     temp.next=current.next;//the temps next is no longer the node but the curr node's next(losing ref to curr
                     size--;
                     }
                  }
                  else{
                  System.out.println("There is no such player in this game");
                  }

                }

            }
        }

    }
}*/
